from django.contrib import admin
from .models import teacher,student,depertment, Hotels,Rooms,Booking,person1,student1



class productadmin(admin.ModelAdmin):
    list_display=('name','mail','phone','subject')

class studentadmin(admin.ModelAdmin):
    list_display=['name','email','rollnumber','school','phone','age']

class student1admin(admin.ModelAdmin):
    list_display=['name','emial','phone','roll','adress']

class depertmentadmin(admin.ModelAdmin):
    list_display=['name','location','img']


class Hotelsadmin(admin.ModelAdmin):
    list_display=['name','location','state','country']


class person1admin(admin.ModelAdmin):
    list_display=['first_name','last_name','birth_date']


class roomadmin(admin.ModelAdmin):
    list_display=['room_type','capacity','price','hotel','status','roomno']


class bookingadmin(admin.ModelAdmin):
    list_display=['check_in','check_out','room','guest','booking_id']


class booksadmin(admin.ModelAdmin):
    list_display=['title','author']


    
    
admin.site.register(teacher,productadmin)
admin.site.register(person1,person1admin)
admin.site.register(student1)
admin.site.register(student,studentadmin)
admin.site.register(depertment,depertmentadmin)
admin.site.register(Hotels,Hotelsadmin)
admin.site.register(Rooms,roomadmin)
admin.site.register(Booking,bookingadmin)


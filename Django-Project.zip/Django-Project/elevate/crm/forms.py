
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import teacher,student,depertment,Hotels,Booking,Rooms,student1
from django.forms.widgets import PasswordInput, TextInput
from django.contrib.auth.models import User
from django import forms


class CreateUserForm(UserCreationForm):
    class Meta:

        model = User
        fields = ['username', 'email', 'password1', 'password2']


class LoginForm(AuthenticationForm):

    username = forms.CharField(widget=TextInput())
    password = forms.CharField(widget=PasswordInput())



class ContactForm(forms.Form):
     class meta:
       model = teacher
       fields=['name','mail','phone','subject']
    

class studentform(forms.Form):
   class meta:
       model = student
       fields=['name','rollnumber','age','school','email','phone']

class depertmentform(forms.Form):
    class meta:
        model=depertment
        fields=['name','location','img']


class hotelform(forms.Form):
    class meta:
        models=Hotels
        fields=['name','location','state','country']


class roomform(forms.Form):
    class meta:
        models:Rooms
        fields=['room_type','capacity','price','roomno','hotel','status']




class student1form(forms.ModelForm):
    class meta:
        model= student1
        fields="__all__"


from .models import Country, City 

class LocationForm(forms.Form):
    country = forms.ModelChoiceField(queryset=Country.objects.all(),
        widget=forms.Select(attrs={"hx-get": "load_cities/", "hx-target": "#id_city"}))
    city = forms.ModelChoiceField(queryset=City.objects.none())

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if "country" in self.data:
            country_id = int(self.data.get("country"))
            self.fields["city"].queryset = City.objects.filter(country_id=country_id)
from django_tables2 import tables
from .models import Person,person1


class persontable(tables.Table):
    class Meta:
        model=Person
        table_name="django_tables2/bootstrap5.html"
        fields=['first_name','family_name']

class PersonTable(tables.Table):
    class Meta:
        model = person1
        sequence = ("last_name", "first_name", "birth_date", )
        exclude = ("user", )

#class PersonTable(tables.Table):
    #class Meta:
        #model = Person
       # #attrs = {'class': 'table'} 
        #template_name = 'django_tables2/bootstrap4.html'
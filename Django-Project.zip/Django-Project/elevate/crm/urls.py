from django.urls import path
from . import views




app_name="crm"

urlpatterns = [

    path('', views.homepage, name="homepage"),
    
    path('ramana/',views.ramana,name='ramana'),

    path("load_cities/", views.load_cities, name="load_cities"),

    path('register', views.register, name="register"),

    path('my-login', views.my_login, name="my-login"),

    path('dashboard', views.dashboard, name="dashboard"),

    path('user-logout', views.user_logout, name="user-logout"),

    path('contact/', views.contact, name="contact"),

    path('posts',views.posts,name='posts'),

    path('student_file',views.student_file, name="student_file"),

    path('dept_file', views.dept_file, name='dept_file'),

    path('rooms', views.room, name='rooms'),

    path('room1', views.room1 , name='room1'),
    
    path('show_room', views.show_room, name='show_room'),


    path('listview/',views.index,name='listview'),

    #path('person-table/', PersonTableView.as_view(), name='person_table'),

    path('person_list',views.person_list,name='person_list'),

    path('person_data',views.person_data,name='person_data'),









]



     
   





    











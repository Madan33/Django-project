from .forms import CreateUserForm, LoginForm,ContactForm,hotelform,roomform
from crm.models import teacher, student,Hotels,Rooms, Booking,Person,person1,student1,City
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import ContactForm,studentform,depertmentform,student1form,LocationForm
from django.http import HttpResponse,HttpResponseRedirect
from .models import teacher,student,depertment,Hotels
from django.shortcuts import render, redirect
from django.contrib.auth.models import auth
from django_tables2 import SingleTableView
from django.views.generic  import ListView
from django.contrib import messages
from .tables import persontable,PersonTable





def homepage(request):

    return render(request, 'student_reg/index.html')

#about contact form 
def contact(request):
    form = ContactForm()
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            cd = form
            try:
                teacher_instance = teacher.objects.create(
                    name=cd.data["name"],
                    mail=cd.data["mail"],
                    phone=cd.data["phone"],
                    subject=cd.data["subject"],
                )
                teacher_instance.save()
                return HttpResponse("Contact saved successfully!") 
            
            except KeyError as e:
                # If KeyError occurs, print it for debugging
                print("KeyError:", e)
                return HttpResponse(f"Error saving Contact: {e}")
        else:
            # Form is not valid, handle accordingly (e.g., display errors)
            print("Form is not valid, Please check your")
    else:
        form = ContactForm()  # If request method is not POST, instantiate a new form

    context = {'ContactForm': form}  # Renamed the context variable for clarity
    return render(request, 'crm/contact.html', context)
        
   


# getting data in admin into web pages
def posts(request):
    context = {}
    context['posts'] = teacher.objects.all()
    return render(request,'crm/posts.html', context)

#About student model
def student_file(request):
    form = studentform()
    if request.method == 'POST':
        form=studentform(request.POST)
        if form.is_valid():
            sd=form
            try:
                sf=student.objects.create(
                    name=sd.data['name'],
                    rollnumber=sd.data['rollnumber'],
                    age=sd.data['age'],
                    school=sd.data['school'],
                    email=sd.data['email'],
                    phone=sd.data['phone'],
                )
                sf.save()
                return HttpResponse("Student saved successfully!")
            
            except KeyError as e:
                # If KeyError occurs, print it for debugging
                print("KeyError:", e)
                return HttpResponse(f"Error saving student: {e}")
        else:
            # Form is not valid, handle accordingly (e.g., display errors)
            print("Form is not valid, Please check your")
    else:
        form=studentform()
    context = {'student':form}
    return render(request, 'student.html', context=context)


#About depertment file
def dept_file(request):
    form = depertmentform()
    if request.method == 'POST':
        form=depertmentform(request.POST)
        if form.is_valid():
            dd=form
            df=depertment.objects.create(
                name=dd.data["name"],
                location=dd.data['location'],
                img=dd.data['img'],
            )
            df.save()
            return HttpResponse( " Depetsaved successfully!")
        
        form=depertmentform()
    
    context = {'theme':form}

    return render(request, 'crm/theme.html', context=context)



def room(request):
    form = hotelform()
    if request.method == 'POST':
        form=hotelform(request.POST)
        if form.is_valid():
            hd=form
            try:
                hf=Hotels.objects.create(
                    name=hd.data['name'],
                    location=hd.data['location'],
                    state=hd.data['state'],
                    country=hd.data['country'],
                    
                )
                hf.save()
                return HttpResponse("Hotel saved successfully!")
            
            except KeyError as e:
                # If KeyError occurs, print it for debugging
                print("KeyError:", e)
                return HttpResponse(f"Error saving Hotel List: {e}")
        else:
            # Form is not valid, handle accordingly (e.g., display errors)
            print("Form is not valid, Please check your")
    else:
        form=studentform()
    context = {'Hotels':form}
    return render(request, 'crm/room_list.html', context=context)



def show_room(request):
    context = {}
    context['show_room'] = Hotels.objects.all()
    return render(request,'crm/show_room.html', context)






def room1(request):
    form = roomform()
    if request.method == 'POST':
        form=roomform(request.POST)
        if form.is_valid():
            rd=form
            try:
                rf=Rooms.objects.create(
                    room_type=rd.data['room_type'],
                    capacity=rd.data['capacity'],
                    price=rd.data['price'],
                    hotel=rd.data['hotel'],
                    roomno=rd.data['roomno'],
                    status=rd.data['status'],
                    
                )
                rf.save()
                return HttpResponse("rooms saved successfully!")
            
            except KeyError as e:
                # If KeyError occurs, print it for debugging
                print("KeyError:", e)
                return HttpResponse(f"Error saving Room List: {e}")
        else:
            # Form is not valid, handle accordingly (e.g., display errors)
            print("Form is not valid, Please check your")
    else:
        form=studentform()
    context = {'Rooms':form}
    return render(request, 'crm/room1_list.html', context=context)









#about register
def register(request):

    form = CreateUserForm()

    if request.method == "POST":

        form = CreateUserForm(request.POST)

        if form.is_valid():

            form.save()
            return HttpResponse("register sucess")
            return redirect("my-login")
       
            
        
        else:
            form = CreateUserForm()
            return render(request, 'crm/register.html', {'form': form})
            
        
#about login
def my_login(request):

    form = LoginForm()

    if request.method == 'POST':

        form = LoginForm(request, data=request.POST)

        if form.is_valid():

            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:

                auth.login(request, user)

                return redirect("dashboard")


    context = {'loginform':form}

    return render(request, 'crm/my-login.html', context=context)






#about logout
def user_logout(request):

    auth.logout(request)

    return redirect("crm/dashboard.html")



@login_required(login_url="my-login")

def dashboard(request):

    return render(request, 'crm/dashboard.html')




def index(request):
    return render(request,'tableindex.html')



class listview(SingleTableView):
    model = Person
    table_class =Person
    template_name = "tables1.html"

#class PersonTableView(SingleTableView):
    #model = Person
    #table_class = PersonTable
   # template_name = 'person_table.html' 


#about Person Table to display 
def person_list(request):
    table = PersonTable(Person.objects.all())

    return render(request, "person_list.html", {
        "table": table
    })

#about to show  person data in admin panel
def person_data(request):
    context = {}
    context['person_data'] = person1.objects.all()
    return render(request,'person_data.html', context)



def ramana(request):
    if request.method == "POST":
        form = LocationForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data["country"])
            print(form.cleaned_data["city"])
        else:
            print(form.errors)
    else:
        form = LocationForm()
    return render(request, 'student_reg/index.html', {"form": form})

def load_cities(request):
    country_id = request.GET.get("country")
    cities = City.objects.filter(country_id=country_id)
    return render(request, "student_reg/base.html", {"cities": cities})
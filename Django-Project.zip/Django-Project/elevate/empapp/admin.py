from django.contrib import admin
from .models import emptable

# Register your models here.

class emptableadmin(admin.ModelAdmin):
    list_display=['name','salary','contact_no','email']

admin.site.register(emptable,emptableadmin)
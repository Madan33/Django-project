from django_tables2 import tables
from .models import emptable



class employeetable(tables.Table):
    class Meta:
        model = emptable
        sequence = ( "salary", "email",'contact' )
        exclude = ("name", )
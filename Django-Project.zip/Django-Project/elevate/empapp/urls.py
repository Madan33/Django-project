from django.urls import path,include
from . import views
from .views import listview

urlpatterns = [
    path('',views.empfun,name='empfun'),
    path('add_table',views.add_table,name='add_table'),
    path('showemp',views.showemp,name='showemp'),
    path('editpage/<int:id>',views.editpage,name='editpage'),
    path('edit_emp/<int:id>',views.edit_emp,name='edit_emp'),
    path('delete_emp/<int:id>',views.delete_emp,name='delete_emp'),


    path('person_table/',views.person_table,name='person_table'),
    path('listview/',listview.as_view(),name='listview'),
]

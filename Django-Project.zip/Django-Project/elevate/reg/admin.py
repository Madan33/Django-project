from django.contrib import admin
from .models import Member,Student

class MemberAdmin(admin.ModelAdmin):
    list_display="firstname","lastname","country"

class studentadmin(admin.ModelAdmin):
    list_display=['student_number', 'first_name', 'last_name', 'email', 'field_of_study', 'gpa']

admin.site.register(Member,MemberAdmin)
admin.site.register(Student,studentadmin)
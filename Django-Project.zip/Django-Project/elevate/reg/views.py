

# Create your views here.
from django.contrib.auth import authenticate, login, logout 
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.core.mail import EmailMultiAlternatives
from django.contrib.auth import authenticate, login
from django.template.loader import get_template
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .forms import SignupForm, LoginForm
from django.core.mail import send_mail
from django.contrib import messages
from .forms import UserRegisterForm
from django.template import Context
from .models import Student
from .forms import StudentForm
from .models import Member,Student
from django.urls import reverse

# Create your views here.
# Home page
def index(request):
    return render(request, 'index.html')

# signup page
def user_signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = SignupForm()
    return render(request, 'signup.html', {'form': form})

# login page
def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)    
                return redirect('home')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})


# logout page
def user_logout(request):
    logout(request)
    return redirect('login')




#Curd Operations

#def index(request):
    mem=Member.objects.all()
    return render(request,'curd/index.html',{'mem':mem})

#def add(request):
    return render(request,'curd/add.html')

#def addrec(request):
    x=request.POST['first']
    y=request.POST['last']
    z=request.POST['country']
    mem=Member(firstname=x,lastname=y,country=z)
    mem.save()
    return redirect("/")

#def delete(request,id):
    mem=Member.objects.get(id=id)
    mem.delete()
    return redirect("/")

#def update(request,id):
    mem=Member.objects.get(id=id)
    return render(request,'curd/update.html',{'mem':mem})

#def uprec(request,id):
    x=request.POST['first']
    y=request.POST['last']
    z=request.POST['country']
    mem=Member.objects.get(id=id)
    mem.firstname=x
    mem.lastname=y
    mem.country=z
    mem.save()
    return redirect("/")